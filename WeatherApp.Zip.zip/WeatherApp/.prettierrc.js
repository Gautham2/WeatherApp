module.exports = {
    bracketSpacing: true,
    singleQuote: true,
    tabWidth: 2,
    useTabs: false,
    trailingComma: "none",
    semi: false
};